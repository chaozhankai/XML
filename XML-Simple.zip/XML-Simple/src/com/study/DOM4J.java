package com.study;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.Iterator;
import java.util.List;

public class DOM4J {
    public static void main(String[] args) {
        // 解析Plant.xml文件
        // 创建SAXReader的对象Reader
        SAXReader reader = new SAXReader();
        try {
            // 通过reader对象的read方法加载books.xml文件，获取document对象
            Document document = reader.read(new File("Plant.xml"));
            // 2018000261668088.xml
            // 通过document对象获取根节点
//            System.out.println(document); 输出后会发现输出的不是里面的内容，而是文件的路径[Document: name file:///D:/MyProject/XML-Simple/2018000261668088.xml]
            Element root = document.getRootElement();
            // 输出的是根节点的名字
            System.out.println("<"+root.getName()+">");
//            // 输出root试试
//            System.out.println("root是：");
//            System.out.println(root);
//            输出的结果为：root是：
//            org.dom4j.tree.DefaultElement@7a78d3 [Element: <plant attributes: []/>]

            // 通过element对象的elementIterator方法获取迭代器
            Iterator iterator = root.elementIterator();
            // 遍历迭代器，获取根节点中的信息
            while (iterator.hasNext()){
//                System.out.println("====开始遍历节点====");
                Element SecondRoot = (Element) iterator.next();
                // 输出的是第二层节点的名字
                System.out.println("\t<"+SecondRoot.getName()+">");
/*              实际的数据处理不需要考虑属性的名称和值，因为没有
                // 获取第二级节点的属性名及属性值
                List<Attribute> SecondRootAttrs = SecondRoot.attributes();
//                System.out.println("属性名"+SecondRootAttrs.getName()+"属性值"+attribute.getValue());
                for (Attribute attribute:SecondRootAttrs){
                    // 输出的是第二层节点的属性名字和属性值，如id="2"
                    System.out.println("\t<"+SecondRoot.getName()+" "+attribute.getName()+"=\""+attribute.getValue()+"\">");
                }
*/
                // 解析子节点的信息
                Iterator iterator1 = SecondRoot.elementIterator();
                while (iterator1.hasNext()){
                    Element ThirdRoot = (Element) iterator1.next();
                    Iterator iterator2 = ThirdRoot.elementIterator();
                    if (iterator2.hasNext()){
                        System.out.println("\t\t<" + ThirdRoot.getName() + ">");
                        while (iterator2.hasNext()){
                            // 输出上级节点的名字
                            Element FourthRoot = (Element) iterator2.next();
                            System.out.println("\t\t\t<"+FourthRoot.getName()+">"+FourthRoot.getStringValue()+"</"+FourthRoot.getName()+">");
                        }
                        System.out.println("\t\t</" + ThirdRoot.getName() + ">");
                    }
                    else {
// 失败的试图解析下一层节点的信息
//                    List<Attribute> ThirdRootAttrs = ThirdRoot.attributes();
//                    for (Attribute attribute:ThirdRootAttrs){
//                        System.out.println("属性名"+attribute.getName()+"属性值"+attribute.getValue());
//                    }
                        // 输出具体的节点名和节点值
                        System.out.println("\t\t<" + ThirdRoot.getName() + ">" + ThirdRoot.getStringValue() + "</" + ThirdRoot.getName() + ">");
                        //Iterator iterator2 = ThirdRoot.elementIterator();
                    }
                }
                System.out.println("\t</"+SecondRoot.getName()+">");
            }
                System.out.println("</"+root.getName()+">");
        }catch (DocumentException e){
            e.printStackTrace();
        }
    }
}






























